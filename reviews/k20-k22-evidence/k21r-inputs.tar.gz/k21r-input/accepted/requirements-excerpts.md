project/technical-coverage.md; full-source SHA256 13486c7ce6600ca82a203c25386a2f7910f66216ffe6754ee7d934f997836580
93: ### K20 — Complex-response alignment and correction feasibility
94: 
95: **Canonical result:** relative amplitude/phase/delay/dispersion response and physically meaningful inverse approximation; distinguish identifiable parameters, feasible compensation and irretrievable information. Develop causality/stability/minimum-phase implications, finite latency/length, coefficient range/resolution and noise gain before choosing analog/digital realization. **Use/assessment:** calculate wideband alignment residuals and deep-attenuation/null contrasts; compare prevention, approximate correction and architecture change before irreversible combination. **Limits:** clipping/aliasing/rank loss without extra information; a notch is not automatically irrecoverable. **Depth:** F correction reasoning; S necessary systems/inverse bridge. K19 supplies digital realization only where selected; K21 owns estimation procedure and validity.
96: 
97: ### K21 — Calibration observability, procedure and maintenance
98: 
99: **First treatment (a):** measurement equations, stimulus/reference uncertainty, nuisance/reference freedoms, rank, omitted paths and desired-observable preservation. **Procedure (b):** combine metrology with observable parameters and feasible correction; acquire, estimate, apply and evaluate held-out residuals, noise gain, coefficient resources and provenance across states/band/environment. **Maintenance (c):** derive cadence, latency, downtime, drift/motion/outage policy and wanted-versus-nuisance transfer; reject invalid compensation or declare degraded operation. **Use/assessment:** demonstrate an indistinguishable calibration case, an executable bounded correction and an independent validity/retained-signal test. **Depth:** F all coherent reasoning; E instrument commands/specialist environmental inputs. A small fit residual is insufficient.
100: 
101: ### K22 — Operational metrology and uncertainty
102: 
103: **Canonical result:** instrument measurement equations including intentional method dependence, loading, fixtures, de-embedding, corrections, correlated references, floor/dynamic range, finite-record uncertainty and traceability. Reuse K07 propagation rather than create a second uncertainty theory. **Use/assessment:** execute or critically evaluate supplied measurements, calculate uncertainty and change reference/fixture topology to test sensitivity. **Limits:** apparent cancellation, instrument floors, estimator bias, insufficient degrees of freedom and nonlinear/ambiguous propagation. **Depth:** F coherent metrology; S general measurement methods; E instrument/calibration-standard particulars. K21a is conditional where calibration observability is needed; executable calibration is not prerequisite to the first measurement treatment.
104: 
163: | K20 | K12 complex transfer; K13 allocations; K04/K07 conditioning/error; internal causal/stable inverse bridge | Add K08 antenna response, K15 distribution, K19 digital realization; no calibration procedure needed to analyze correction feasibility |
164: | K21a | K01 observables, K05 identifiability, K04 rank and K07 sensitivity | Add K08 external paths, K20 multichannel alignment, K09 physical noise |
165: | K22 | K01 measurand, K03 finite observation, K05 estimator behavior, K07 uncertainty | Add K21a calibration references; K04/K09 coupled noise; K17/K19 sampled measurement |
166: | K21b | K21a identified freedoms; K22 metrology; K05/K07 inference/uncertainty | Add K18/K19/K20 selected correction, K23a state validity, K08 field/sensor calibration |
167: | K21c | K21b valid procedure; K03 drift observation; K06 wanted/nuisance transfer | Add K08 motion/transduction, K16 holdover and K24b environmental evidence |
207: | CAP-022 | C/M/A/D/I/V | K20; add K08 vector, K15 reference, K19 digital | Estimated/aligned complex response; independent band/state residual, coefficient/noise/latency limits and deep-attenuation case before combination | P-ARR, X-INV; U-05/U-10 |
208: | CAP-023 | C/M/A/D/V | K21a; add K08 field, K20 multichannel, K09 noise | Evaluated calibration equations; indistinguishable parameter sets, omitted-path faults and reference freedoms; distinguish fit from correction feasibility | P-DF, P-SEN; U-05/U-10 |
209: | CAP-024 | C/M/A/D/I/V | K21b, K22; add selected K18/K19/K20/K23a/K08 | Executed bounded calibration with held-out data/conditions, uncertainty/noise gain/resources and retained wanted signal; reject invalid correction | X-INV, X-PROD; U-10 |
210: | CAP-025 | C/M/A/D/I/V | K21c; add K08 dynamics, K16 holdover, K24b environment | Evaluated cadence/latency/downtime policy under drift/fades/outage; quantify desired and nuisance response and degraded/recovery limits | P-SEN, P-INT; U-04 |
215: | CAP-030 | C/M/A/D/I/V | K22; add K21a calibration, K04/K09 coupled noise, K17/K19 sampled | Executed or critically evaluated measurement; covariance/finite-record uncertainty, floor/fixture/reference sensitivity and independent configuration | P-MET, P-INT; U-01/U-09 |
project/annotated-toc.md; full-source SHA256 9441c0715abdab2c7da078ee8729dc18c6501bf6b6916356d69fbd4952d5cdcb
328: ### Chapter 13 — Calibration observability and operational metrology
329: 
330: **Objective:** Distinguish identifiable parameters from measurement precision and construct a sensitive test.
331: 
332: **Entry:** Chapters 1, 3–6; external paths add 8, physical noise 9.
333: 
334: **Canonical ownership:** K21a; K22. Shared results used here retain their original homes.
335: 
336: #### 13.1 Calibration measurement freedoms
337: 
338: Write stimulus/reference/nuisance equations, rank and reference constraints. Exhibit indistinguishable parameters and omitted paths before choosing a correction.
339: 
340: #### 13.2 Operational measurement equations
341: 
342: Develop intentional method-defined observables versus instrument imperfections, loading, floors, fixtures, de-embedding and correlated references.
343: 
344: #### 13.3 Uncertainty and records
345: 
346: Apply Chapter 6 propagation to sensitivity, bias, finite records/effective degrees of freedom and traceability. Treat nonlinear/ambiguous uncertainty explicitly where needed.
347: 
348: #### 13.4 Independent configurations
349: 
350: Compare cable/level/reference topology and supplied measurements to distinguish DUT from instrument artifacts. Measurement reasoning precedes executable calibration in Chapter 23.
351: 
352: **Examples, engineering work and verification:** D-MET and P-INT need interpreted data/uncertainty and a test-sensitivity assessment. Chapter 24 owns compliance decision rules; a small fit residual proves neither correction nor accuracy.
512: ### Chapter 20 — Complex-response alignment and feasible correction
513: 
514: **Objective:** Distinguish known response, achievable compensation and lost information.
515: 
516: **Entry:** Chapters 4, 6, 11–12; fields add 8, digital realization 19.
517: 
518: **Canonical ownership:** K20. Shared results used here retain their original homes.
519: 
520: #### 20.1 Relative response over bandwidth
521: 
522: Develop amplitude/phase/delay/dispersion alignment and allocation across channel, band and state.
523: 
524: #### 20.2 Inverse approximation bridge
525: 
526: Develop necessary causal/stable/minimum-phase reasoning and finite-latency/length alternatives; formal inversion is insufficient.
527: 
528: #### 20.3 Noise and information limits
529: 
530: Calculate coefficient range/resolution, noise gain and residuals for attenuation, deep null and true rank-loss cases; do not classify every notch as irrecoverable.
531: 
532: #### 20.4 Correction access and prevention
533: 
534: Compare physical matching, analog/digital approximation and architecture change before irreversible combination. Procedural estimation/validity returns in Chapter 23.
535: 
536: **Examples, engineering work and verification:** D-ARR/X-INV require independent band/state residuals and a rejected correction. Analog alignment remains a valid route without DDC.
537: 
538: ## Part IV — Valid operation and engineering evidence
539: 
540: ### Chapter 21 — State causality, integration and diagnosis
541: 
542: **Objective:** Preserve observable meaning through transitions and discriminate faults.
543: 
544: **Entry:** Chapters 1, 11–13; add selected realization/reference methods only.
545: 
546: **Canonical ownership:** K23a/b/c. Shared results used here retain their original homes.
547: 
548: #### 21.1 Transition causality
549: 
550: Trace applicable PLL/divider/sampler/FIFO/NCO/filter states; distinguish epoch, transport latency, RF phase and calibration validity.
551: 
552: #### 21.2 Integrated configuration
553: 
554: Develop startup/reset/retune/link/reference-loss sequences, channel/sample identity, coefficient versions, logging and valid-data gates.
555: 
556: #### 21.3 Fault injection and recovery
557: 
558: Specify bounded integrated exercises for partial reset, drops, stale coefficients and outage; preserve raw evidence and observe end-to-end response.
559: 
560: #### 21.4 Diagnostic interventions
561: 
562: Use frequency/time/channel/environment signatures, controlled substitutions and competing hypotheses. Chapter 24 supplies rare-event confidence, not an arbitrary repeat count.
563: 
564: **Examples, engineering work and verification:** X-STATE and D-MET require an exercised path and supported diagnosis; successful communication or framing alignment is insufficient.
565: 
566: ### Chapter 22 — Physical and environmental engineering
567: 
568: **Objective:** Translate allocations into concrete physical constraints and controlled evidence.
569: 
570: **Entry:** Chapters 6, 11–12, 14 and RF interconnect baseline; selected paths add 15/17/19/20.
571: 
572: **Canonical ownership:** K24a/b. Shared results used here retain their original homes.
573: 
574: #### 22.1 Coupling and power paths
575: 
576: Calculate representative aggressor/supply-to-phase contributions; develop return-current, impedance, isolation, regulator/filter and shield choices.
577: 
578: #### 22.2 Layout and access
579: 
580: Specify routing/stack-up/distribution/test-access constraints from sensitivities; equal physical length does not guarantee electrical matching.
581: 
582: #### 22.3 Thermal and mechanical response
583: 
584: Develop coefficients, gradients, time constants, strain, vibration, connectors and warmup. Bound externally supplied material/fabrication facts.
585: 
586: #### 22.4 Mitigation and comparison
587: 
588: Calculate residual sensitivity and interpret controlled gradient/cycling/handling or aggressor tests with reference controls; uniform chamber evidence is limited.
589: 
590: **Examples, engineering work and verification:** D-ARR/D-MET and X-PROD connect constraints to budgets and field validity. Calibration interfaces may be supplied before maintenance policy; no generic layout checklist discharges this chapter.
592: ### Chapter 23 — Calibration procedures and continued coherence
593: 
594: **Objective:** Execute valid correction and choose maintenance without removing wanted information.
595: 
596: **Entry:** Chapter 13 plus 3, 5–7; selected corrections 18–20, states 21, environment 22.
597: 
598: **Canonical ownership:** K21b/c. Shared results used here retain their original homes.
599: 
600: #### 23.1 Acquisition to correction
601: 
602: Combine observable parameters, uncertain stimuli and feasible correction; develop ordering, interpolation/regularization and coefficient provenance.
603: 
604: #### 23.2 Held-out validity
605: 
606: Evaluate independent band/gain/level/state/environment residuals, noise gain, coefficient resources and desired-signal transfer; reject invalid corrections.
607: 
608: #### 23.3 Maintenance policy
609: 
610: Derive update cadence/latency/downtime from drift/motion and task sensitivity, including environmental evidence and remote holdover where applicable.
611: 
612: #### 23.4 Degraded operation and change
613: 
614: Evaluate fades/outages, stale calibration and reacquisition; declare invalid intervals and retain configuration. Compare fixed correction, periodic calibration and tracking.
615: 
616: **Examples, engineering work and verification:** All anchors use bounded executed/evaluated procedures. P-SEN explicitly varies wanted and nuisance inputs; a smaller fit or operational residual is insufficient evidence.
