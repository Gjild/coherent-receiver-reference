Verbatim accepted K11 requirements and canonical destinations. K13 later adds allocation to the shared Chapter12; this review is bounded K11.

### K11 — Requirements, joint feasibility and architecture selection

**First treatment:** formulate operational needs, states, observables, missing limits and evidence routes. **Quantitative refinement:** intersect information, ambiguity, energy/bandwidth/time, dynamics, headroom, latency and technology/resource constraints; distinguish empty, conditional and evidenced feasible regions. **Use/assessment:** calculate gain-range and information/steering conflicts, compare architectures and quantitative interfaces, identify which change restores feasibility. **Limits:** local precision is not global acquisition; supplied technology envelopes are assumptions until evidenced. **Depth:** F coherent systems reasoning; S generic systems/constrained analysis; E actual contracts, regulations and device facts. K13/subsystem results refine the initial feasible region through engineering interaction.

#### 1.4 Requirements before numbers

Frame needs, operating states, evidence and missing limits. Compare coherent and noncoherent choices qualitatively; preview later feasibility rather than assume it.

**Examples, engineering work and verification:** Compare two intentionally different measurands and reconstruct a signal through inversion. Show what each test could establish; no common clock is assumed to guarantee phase.

### Chapter 12 — Feasibility, architecture and correlated allocations

**Objective:** Reject incompatible goals, compare architectures and close conditional allocations.

**Entry:** Chapters 5–6, 9 and 11; spatial/detection constraints add 8/10.

**Canonical ownership:** K11 quantitative; K13. Shared results used here retain their original homes.

#### 12.1 Joint feasible regions

Intersect information/ambiguity, energy/bandwidth/time, dynamics, headroom, latency and resource constraints. Calculate both gain-range and task-information/steering conflicts.

#### 12.2 Architecture and interfaces

Compare analog/digital/hybrid and shared/independent-reference alternatives with quantitative loading, drive, noise, power, latency and calibration-access envelopes.

#### 12.3 Correlated budget construction

Propagate Chapter 9 physical sources and cross-spectra to observables; distinguish margins, variability, uncertainty, correction residual and measurement uncertainty.

#### 12.4 Closure and restoration

Vary correlation, blocker, environment or missing inputs; identify which requirement/architecture change restores feasibility. Reconcile supplied application mappings and technology envelopes in later design stages.

**Examples, engineering work and verification:** All anchors need a rejected alternative and a conditional/empty feasible region. Actual technology guarantees and application limits remain inputs, not assumed performance.


| K11 first framing | Reader operational/RF baseline; K01 for quantitative observable definitions | Application need supplied; no budget result assumed |
| K11 quantitative | K05 information/ambiguity; K07 bounded calculation; K01 requirement conditions | Add K08/K04 spatial constraints, K10 detection, K09 disturbance constraints; technology/interface envelopes may be supplied |
| CAP-001 | C/A/D/V | K11, K01, K25 | Requirement/state/evidence set; identify missing limits and reject or qualify incompatible goals using calculated feasibility | All P cases; U-01/U-07 |
| CAP-011 | C/A/D/I/V | K11 quantitative, K12; add K08 apertures, K16 remote | Compared architectures with calculated drive/loading/noise/latency/power/calibration interfaces; resolve incompatibility or preserve missing evidence | P-RAD, X-BLK; U-07 |
| CAP-043 | C/M/A/D/V | K11 quantitative; add K04/K08 spatial, K10 detection, K09 disturbance | Calculated intersecting gain/headroom and information/ambiguity or steering constraints; empty/conditional region and justified restoring change | X-BLK, P-DF, P-ARR; U-01/U-09 |
| K11 | 001, 011, 013, 031, 043 |
