"""Distinct double-sum, limits, loading sensitivities and coherent-floor checks."""
import unittest,sys,math,cmath
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'engineering/examples'))
import metrology_models as m
class MetrologyFoundations(unittest.TestCase):
    def test_pair_counts_and_white_limit(self):
        for n in [2,3,11,100]:
            got=sum(.9**abs(i-j) for i in range(n) for j in range(n))/n**2
            self.assertAlmostEqual(got,m.mean_factor(n),places=14)
            self.assertAlmostEqual(m.mean_factor(n,0),1/n)
            self.assertAlmostEqual(m.variance_dof(n,0),n-1,places=10)
        self.assertLess(1/m.mean_factor(100),6)
        self.assertNotAlmostEqual(m.variance_dof(100),1/m.mean_factor(100)-1)
    def test_loading_finite_differences(self):
        z=45+5j;step=1e-4
        g=[(cmath.phase(m.loading(z+step*v))-cmath.phase(m.loading(z-step*v)))/(2*step) for v in [1,1j]]
        self.assertAlmostEqual(.2*math.hypot(*g),m.loading_uncertainty(),places=11)
        self.assertEqual(m.loading(50),.5)
    def test_coherent_floor_tangent_and_range(self):
        A=.02;B=.0002;alpha=math.asin(B/A)
        tangent=complex(A-B*B/A,B*math.sqrt(1-(B/A)**2))
        self.assertAlmostEqual(abs(tangent-A),B,places=16)
        self.assertAlmostEqual(cmath.phase(tangent),alpha)
        self.assertGreater(alpha,.002);self.assertLess(math.asin(B/.12),.002)
        self.assertGreater(B/math.sin(.002),.1)
