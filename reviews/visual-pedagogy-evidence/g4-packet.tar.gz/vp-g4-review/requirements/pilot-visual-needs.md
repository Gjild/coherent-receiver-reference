### V23 — Indispensable

- Location: `relative-phase-stability.qmd`, **A fair endpoint comparison**.
- Form/content: Endpoint architecture panels and integrated variance versus branch-density tradeoff with limit and example envelopes.
- Purpose/error prevented: Explain preference reversal from distribution noise; avoid universal architectural superiority.
- Model, labels and assumptions: Pilot G, Sr=1e−6 rad²/Hz two-sided 1≤|f|≤10000 Hz; delay mismatch 10/100 ns; b per endpoint rad²/Hz, RMS degrees; independent branches only.
- Independent check: Independent integration versus Vcommon+39996b; reproduce table and ~1.71e−8 branch threshold.

### V24 — Indispensable

- Location: `relative-phase-stability.qmd`, **Calibration, drift and implementation**.
- Form/content: Fixed-LO calibration measurement arrangement with training/held-out comb tones, Q-to-O acquisition and fixture slope explicitly shown.
- Purpose/error prevented: Show what calibration can identify and why retuning or fixture unknowns confound delay.
- Model, labels and assumptions: RF MHz, fixed 990 MHz LO, IF 9–11.5 MHz; 32 Msample/s before channelization, 100 ksample/s per tone; P/L/Q/O; distinguish known-stimulus from wanted use.
- Independent check: Trace fixed-LO and retuned slope equations; verify all tone/IF frequencies and held-out exclusion from fit.

### V25 — Indispensable

- Location: `relative-phase-stability.qmd`, **Thermal reference and maintenance allocation**.
- Form/content: Calibration snapshot/application timeline with gated data, correction age sawtooth and bounded drift.
- Purpose/error prevented: Prevent using snapshot center as application time or adding SD to a deterministic bound.
- Model, labels and assumptions: P=2 s, T=.01/.05 s, settle .02 s, after-end latency .1 s; seconds, degrees; drift .216°/s; 0.5° deterministic limit separate from snapshot SD.
- Independent check: Oldest age P+T/2+.1; center bias .216T/4; .45522/.46170°; gated fractions 6.5/8.5%.

### V26 — Indispensable

- Location: `relative-phase-stability.qmd`, **Constant uncertainty and time-varying updates**.
- Form/content: Frozen coefficient versus update staircase and observation mask; randomized-origin triangular covariance and sinc² PSD panel.
- Purpose/error prevented: Prevent static accuracy uncertainty being added to DC-rejecting variance or update noise discarded as DC.
- Model, labels and assumptions: c held between updates; t/P and fP dimensionless; Rc/vc triangle, Sc/(vcP)=sinc²; stationary only for independent errors with uniformly randomized origin.
- Independent check: Zero-sum weights reject a constant; Fourier triangle transform and integrated PSD area vc; cross-covariances retained for general case.

### V27 — Indispensable

- Location: `relative-phase-stability.qmd`, **Measurement and uncertainty: an executable protocol**.
- Form/content: Measurement-chain/swap diagram including source, fixtures, receivers, acquisition and independent Q comparison.
- Purpose/error prevented: Prevent agreement of correlated measurements being treated as absolute truth; expose swap invariants.
- Model, labels and assumptions: Use eq-measurement at fixed channel labels; independent comparison has its own acquisition/instrument terms and shared δQ; no blanket independence.
- Independent check: Term-by-term sign table for input fixture swap and acquisition swap; m−m′ removes δQ, retains instrument difference.

### V28 — Strongly beneficial

- Location: `relative-phase-stability.qmd`, **Measurement and uncertainty: an executable protocol**.
- Form/content: Guarded-decision intervals relative to a scalar upper limit.
- Purpose/error prevented: Separate guaranteed bound from SD and show inconclusive overlap.
- Model, labels and assumptions: Generic scalar y with declared units; bound U, limit L; no assumed coverage or compliance evidence.
- Independent check: Boundary equalities yhat+U=L and yhat−U=L; inequalities agree with text.

V24 additional teaching requirement: show asymmetric training frequencies 999,1000,1001.5 MHz and excluded 1000.5 MHz; distinguish mean-frequency intercept .297905605 rad from .3 rad at 1000 MHz for a 2 ns slope. Scalar carrier subtraction leaves frequency-dependent phase. Connect the pilot to general phasor/noise, observation, covariance, ambiguity and signal-retention teaching without duplicating general illustrations. The existing state diagram requires explicit invalid-data gating and requalification routes.
