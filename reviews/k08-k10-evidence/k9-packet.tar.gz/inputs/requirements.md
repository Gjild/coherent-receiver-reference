Verbatim accepted requirement extracts, not author self-assessment.

### K09 — Physical disturbance generation and paths

**Canonical result:** convert physical thermal/representative active-device and external-field noise through loaded/coupled networks into delivered spectra and covariance. Develop reciprocal mixing with effective LO spectra, blocker/preselection/observation filtering and internal branch contributions; develop timing-error disturbance from the complete analog waveform and clock process. **Use/assessment:** calculate narrow-blocker/flat-spectrum limits and finite-spectrum contrasts; construct coupled covariance and derive filter/LO/clock constraints. **Limits:** source independence, impedance/power normalization, stationarity, small timing errors and unavailable physical parameters. **Depth:** F coherent source/path reasoning; S noise-network bridge; E detailed device physics and verified parameters. K13 assembles, rather than regenerates, these contributions.


### Chapter 9 — Physical noise, blockers and timing disturbances

**Objective:** Construct physical spectra/covariance and derive constraints from the complete waveform.

**Entry:** Chapters 2–4 and RF noise/network baseline; incident fields add 8.

**Canonical ownership:** K09. Shared results used here retain their original homes.

#### 9.1 Sources, loading and delivered noise

Bridge available/delivered power, temperature, thermal and representative active-device noise to network transfer with explicit impedances and normalization.

#### 9.2 Coupled and external noise

Construct covariance from loaded/coupled receiver and field paths rather than assume independent LNAs. Separate supplied parameters from derived relationships.

#### 9.3 Reciprocal mixing

Derive blocker/effective-LO contributions through preselection, mixer branches and observation filtering. Compare narrow-blocker/flat-spectrum limits with finite-spectrum cases.

#### 9.4 Timing-error generation

Derive small timing-error disturbance from the entire analog waveform and clock process, retaining correlations. Identify breakdown of tone-only, stationary and small-error models.

**Examples, engineering work and verification:** X-BLK derives LO/clock/filter constraints; P-INT/D-ARR use physical covariance. Missing device evidence stays open; budget assembly belongs to Chapter 12.

