Verbatim accepted annotated TOC; full source SHA256 9441c0715abdab2c7da078ee8729dc18c6501bf6b6916356d69fbd4952d5cdcb
618: ### Chapter 24 — Verification coverage and bounded conclusions
619: 
620: **Objective:** Evaluate requirements evidence with uncertainty, coverage and justified confidence.
621: 
622: **Entry:** Chapters 6, 12–13; add actual subsystem/application evidence.
623: 
624: **Canonical ownership:** K25. Shared results used here retain their original homes.
625: 
626: #### 24.1 Requirement-evidence arguments
627: 
628: Map operational claims to analysis/inspection/test/demonstration with state/environment/configuration and unresolved corners.
629: 
630: #### 24.2 Decision rules near limits
631: 
632: Use measurement uncertainty, model limitations and declared rules to assess a supplied borderline case; do not fold every uncertainty into arbitrary margin.
633: 
634: #### 24.3 Finite exposure and rare failures
635: 
636: Calculate defensible duration/exposures and bounds for slips/restarts with dependence assumptions. Zero observed failures does not imply zero probability.
637: 
638: #### 24.4 Kinds of assurance
639: 
640: Separate algebra/software consistency, physical applicability, engineering adequacy and system compliance; identify additional empirical evidence and human review needed.
641: 
642: **Examples, engineering work and verification:** X-STATE/X-PROD need evaluated evidence cases and bounded conclusions. Earlier verification previews point here for full decision methods.
