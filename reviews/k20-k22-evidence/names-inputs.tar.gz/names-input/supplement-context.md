Verbatim book/index.qmd excerpt:

Bounded canonical treatments now occupy Chapters 1–20, including the measurement
reasoning in Chapter 13, and the calibration treatment in Chapter 23. Chapters
21 and 22 remain explicitly reserved for state integration and physical/environmental
engineering. Their slots preserve the accepted chapter destinations; supplied
contracts in the developed examples do not complete those missing methods or
any entire planned chapter. The publishing demonstration and relative-phase pilot
are grouped as **development supplements**. Their temporary rendered numbers after
Chapter 23 do not supply later canonical treatments.

