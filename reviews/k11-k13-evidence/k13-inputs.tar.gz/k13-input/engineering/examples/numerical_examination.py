import numpy as np,math,sys,json
from pathlib import Path
sys.path.insert(0,'engineering/examples');import system_models as m
rng=np.random.default_rng(131313);hu,hv=map(np.array,m.thermal_paths());result=[]
# Direct complex voltages and inverse manifold; separate from linear phase formula.
for T in [.001,.002]:
 c=m.allocation_case(T=T);n=1200000;q=.02
 v=np.array(m.nominal_allocation()['v']);sig=math.sqrt(1/(2*c['rho_min']))
 common=rng.normal(size=n)+1j*rng.normal(size=n)
 local=rng.normal(size=(n,3))+1j*rng.normal(size=(n,3))
 noise=sig*(math.sqrt(1-q)*local+math.sqrt(q)*common[:,None]*v)
 phase=np.angle(1+noise);cal=rng.normal(0,.01,(n,3));u=rng.normal(0,2,n);vv=rng.normal(0,2,n)
 dif=phase[:,1:]-phase[:,:1]+cal[:,1:]-cal[:,:1]+u[:,None]*hu+vv[:,None]*hv
 truth=math.sin(math.pi/3);est=np.arcsin(truth+dif[:,1]/(8*math.pi));delta=np.degrees(est-math.pi/3)
 variance=np.var(dif[:,1]);sd=np.std(delta);bias=np.mean(delta)
 linear=c['total_phase_variance'];result.append({'T':T,'trials':n,'nonlinear_phase_variance':float(variance),'linear_envelope_variance':linear,'ratio':float(variance/linear),'angular_sd_degrees':float(sd),'angular_mean_shift_degrees':float(bias),'linear_sd_degrees':c['sigma_degrees']})
 assert abs(variance/linear-1)<.015
 # Numerical sensitivity check, not a certified remainder or tail bound.
 assert sd>.5 if T==.001 else sd<.405
print(json.dumps(result,indent=2));Path('/tmp/k1113/k13-nonlinear-check.json').write_text(json.dumps(result,indent=2)+'\n')
