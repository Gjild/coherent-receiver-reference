from pathlib import Path
import math,json,re,xml.etree.ElementTree as E,sys
sys.path.insert(0,'engineering/examples');import subsystem_models as m,visual_foundations as v
out=Path('/tmp/k1416/svg14');out.mkdir(exist_ok=True);v.OUT=out;m.unit14()
assert all(f.read_bytes()==(Path('book/figures')/f.name).read_bytes() for f in out.glob('*.svg'))
lin=lambda a,b:[a+(b-a)*i/240 for i in range(241)]
checks=[]
def check(name,y,xlim,ylim,curves,log=False):
 top=y+92;fy=math.log10 if log else lambda x:x
 paths=[]
 for p in E.parse('book/figures/'+name+'.svg').getroot():
  pts=[tuple(map(float,q)) for q in re.findall(r'[ML]([\d.-]+),([\d.-]+)',p.attrib.get('d',''))]
  if p.attrib.get('stroke-width')=='2.8' and len(pts)>2 and top-.001<=pts[0][1]<=top+195.001:paths.append(pts)
 wanted=[]
 for xs,ys in curves:
  chunk=[]
  for x,z in zip(xs,ys):
   if ylim[0]<=z<=ylim[1]:chunk.append((100+780*(x-xlim[0])/(xlim[1]-xlim[0]),top+195-195*(fy(z)-fy(ylim[0]))/(fy(ylim[1])-fy(ylim[0]))))
   else:
    if len(chunk)>1:wanted.append(chunk)
    chunk=[]
  if len(chunk)>1:wanted.append(chunk)
 assert len(paths)==len(wanted),(name,y,len(paths),len(wanted))
 for got,w in zip(paths,wanted):
  assert len(got)==len(w)
  error=max(max(abs(a-c),abs(b-d)) for (a,b),(c,d) in zip(got,w));assert error<.000501
  checks.append({'figure':name,'vertices':len(got),'max_error_px':error})
aa=lin(40,52)
peak=lambda a:10*math.log10((2*math.sqrt(10**((26-a)/10))+math.sqrt(10**(-56/10)))**2)
check('analog-blocker-region',75,(40,52),(-21,-7),[(aa,[peak(a) for a in aa])]+[(aa,[z]*241) for z in [-10,-13,-16]])
xx=lin(42.1,52)
bias=lambda a:math.degrees(math.asin(sum(10**((3*(-20-a+g)-2*ip+rest+56)/20) for g,ip,rest in [(0,0,46),(20,20,26),(26,25,20)])))
check('analog-blocker-region',520,(42.1,52),(0,.05),[(xx,[bias(a) for a in xx]),(xx,[.02]*241)])
tt=lin(0,240)
check('analog-memory-recovery',70,(0,240),(.01,10),[(tt,[8*(1-math.exp(-2))*math.exp(-t/40) for t in tt]),(tt,[8*math.exp(-t/40) for t in tt]),(tt,[.1]*241)],True)
tt=list(range(241));phase=lambda t:8*(1 if t<10 else math.exp(-(t-10)/40))+3*math.exp(-(t if t<30 else t-30)/15)
check('analog-validity-policy',70,(0,240),(-.1,1.1),[(tt,[int(t>=30) for t in tt]),(tt,[int(t>=186) for t in tt])])
check('analog-validity-policy',515,(0,240),(.01,12),[(tt,[phase(t) for t in tt]),(tt,[.1]*241)],True)
r={'reproduced':4,'checks':checks,'vertices':sum(x['vertices'] for x in checks)};Path('/tmp/k1416/k14-graphical.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'figures':4,'vertices':r['vertices']}))
