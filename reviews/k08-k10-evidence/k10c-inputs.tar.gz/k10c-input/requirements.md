Verbatim accepted requirement extracts, not author self-assessment.

### K10 — Detection, integration and signal-preserving rejection

**Canonical result:** correlation/matched filtering, applicable sufficient-statistic/likelihood reasoning, colored-noise weighting, coherent/noncoherent accumulation and reference mismatch. Develop separation/degree-of-freedom limits and effects of contaminated training or reference leakage. **Use/assessment:** realize and evaluate a bounded extraction/rejection method, calculating retained desired information, detection/correlation outcome and uncertainty. **Limits:** indistinguishable subspaces, finite support, covariance conditioning and pre-digital clipping. **Depth:** F coherent extraction/rejection; S general detection theory; E exhaustive adaptive/mission algorithms. Applications own their hypotheses, waveform mappings and task consequences.


### Chapter 10 — Extraction, integration and rejection

**Objective:** Derive a realizable extraction method and evaluate retained information.

**Entry:** Chapters 3–5; physical interference adds 8–9.

**Canonical ownership:** K10. Shared results used here retain their original homes.

#### 10.1 Hypotheses and correlation

Develop representative likelihood/sufficient-statistic and matched-filter reasoning with explicit hypotheses and normalization.

#### 10.2 Colored weighting and accumulation

Derive coherent/noncoherent integration and mismatch consequences using Chapter 3 observation statistics, not a universal phase-loss rule.

#### 10.3 Separation and contaminated references

Develop spatial/spectral/temporal or reference-assisted rejection, degrees of freedom, training support, conditioning and leakage.

#### 10.4 Realizable decision and failure

Specify bounded extraction/rejection, false-alarm/detection conditions and retained wanted response. Digital realization follows later; analog survival must already be satisfied.

**Examples, engineering work and verification:** D-COM and P-INT compare matched/mismatched extraction; X-INV tests indistinguishable subspaces. Apparent rejection alone is not improved task performance.

