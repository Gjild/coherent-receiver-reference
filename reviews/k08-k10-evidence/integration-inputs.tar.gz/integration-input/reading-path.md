[Fields, geometry and physical transduction](fields-geometry-transduction.qmd)
then connects incident fields to loaded receiver voltages and shows what electronic
injection cannot establish. [Physical disturbances](physical-disturbance-paths.qmd)
constructs noise and interference from sources and their actual transfer paths.
[Extraction, integration and rejection](extraction-integration-rejection.qmd)
uses those responses and disturbances to calculate detection outcomes and retained
wanted information. Each bounded unit includes a worked receiver decision, a
misleading alternative and a changed-assumption exercise. Their diagrams and
calculations describe supplied models; they do not establish hardware behavior
or complete the planned chapters.

