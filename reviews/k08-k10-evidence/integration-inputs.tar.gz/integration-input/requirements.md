Verbatim accepted K08–K10 treatment and canonical chapter requirements; no author assessment.

### K08 — Propagation, geometry and physical transduction

**Canonical result:** phase/delay/Doppler and minimum vector field-to-port/sensor models, with bases, reference geometry, effective response, loading/coupling and cross-polar leakage. Derive the conditions for a scalar channel model. **Use/assessment:** calculate direction/frequency/polarization or sensor dependence and show which external-path changes internal injection cannot establish. **Limits:** narrowband/far-field/quasi-static assumptions, multipath, geometry and nuisance transduction. **Depth:** F minimum receiver model; S supporting fields/propagation; E full-wave radiators, detailed environments and specialist sensor laws. Externally supplied models must expose uncertainty and conventions.

### K09 — Physical disturbance generation and paths

**Canonical result:** convert physical thermal/representative active-device and external-field noise through loaded/coupled networks into delivered spectra and covariance. Develop reciprocal mixing with effective LO spectra, blocker/preselection/observation filtering and internal branch contributions; develop timing-error disturbance from the complete analog waveform and clock process. **Use/assessment:** calculate narrow-blocker/flat-spectrum limits and finite-spectrum contrasts; construct coupled covariance and derive filter/LO/clock constraints. **Limits:** source independence, impedance/power normalization, stationarity, small timing errors and unavailable physical parameters. **Depth:** F coherent source/path reasoning; S noise-network bridge; E detailed device physics and verified parameters. K13 assembles, rather than regenerates, these contributions.

### K10 — Detection, integration and signal-preserving rejection

**Canonical result:** correlation/matched filtering, applicable sufficient-statistic/likelihood reasoning, colored-noise weighting, coherent/noncoherent accumulation and reference mismatch. Develop separation/degree-of-freedom limits and effects of contaminated training or reference leakage. **Use/assessment:** realize and evaluate a bounded extraction/rejection method, calculating retained desired information, detection/correlation outcome and uncertainty. **Limits:** indistinguishable subspaces, finite support, covariance conditioning and pre-digital clipping. **Depth:** F coherent extraction/rejection; S general detection theory; E exhaustive adaptive/mission algorithms. Applications own their hypotheses, waveform mappings and task consequences.


### Chapter 8 — Fields, geometry and physical transduction

**Objective:** Construct the minimum physical input model and expose what receiver injection cannot establish.

**Entry:** Chapters 1 and 4 plus declared RF fields baseline; inference adds 5.

**Canonical ownership:** K08. Shared results used here retain their original homes.

#### 8.1 Propagation and geometry

Develop phase/delay/Doppler and reference geometry, distinguishing propagation from electronic delay; identify multipath and near/far-field assumptions.

#### 8.2 Vector field to receiver ports

Bridge field/polarization bases, effective response, manifold, phase centers and loading/coupling. Keep the minimum receiver model internal.

#### 8.3 Scalar reduction and its failure

Derive conditions for scalar channels and quantify a direction/frequency/polarization mismatch; include cross-polar leakage and unobserved paths.

#### 8.4 Physical sensing interfaces

Develop representative transduction/reference paths and externally required laws with uncertainty. Detailed radiator synthesis, full-wave design and specialist sensor physics remain bounded external inputs.

**Examples, engineering work and verification:** D-ARR compares electronic and field calibration; P-SEN separates measurand from nuisance. Specialist review must challenge scalar limits and interferometric geometry.

### Chapter 9 — Physical noise, blockers and timing disturbances

**Objective:** Construct physical spectra/covariance and derive constraints from the complete waveform.

**Entry:** Chapters 2–4 and RF noise/network baseline; incident fields add 8.

**Canonical ownership:** K09. Shared results used here retain their original homes.

#### 9.1 Sources, loading and delivered noise

Bridge available/delivered power, temperature, thermal and representative active-device noise to network transfer with explicit impedances and normalization.

#### 9.2 Coupled and external noise

Construct covariance from loaded/coupled receiver and field paths rather than assume independent LNAs. Separate supplied parameters from derived relationships.

#### 9.3 Reciprocal mixing

Derive blocker/effective-LO contributions through preselection, mixer branches and observation filtering. Compare narrow-blocker/flat-spectrum limits with finite-spectrum cases.

#### 9.4 Timing-error generation

Derive small timing-error disturbance from the entire analog waveform and clock process, retaining correlations. Identify breakdown of tone-only, stationary and small-error models.

**Examples, engineering work and verification:** X-BLK derives LO/clock/filter constraints; P-INT/D-ARR use physical covariance. Missing device evidence stays open; budget assembly belongs to Chapter 12.

### Chapter 10 — Extraction, integration and rejection

**Objective:** Derive a realizable extraction method and evaluate retained information.

**Entry:** Chapters 3–5; physical interference adds 8–9.

**Canonical ownership:** K10. Shared results used here retain their original homes.

#### 10.1 Hypotheses and correlation

Develop representative likelihood/sufficient-statistic and matched-filter reasoning with explicit hypotheses and normalization.

#### 10.2 Colored weighting and accumulation

Derive coherent/noncoherent integration and mismatch consequences using Chapter 3 observation statistics, not a universal phase-loss rule.

#### 10.3 Separation and contaminated references

Develop spatial/spectral/temporal or reference-assisted rejection, degrees of freedom, training support, conditioning and leakage.

#### 10.4 Realizable decision and failure

Specify bounded extraction/rejection, false-alarm/detection conditions and retained wanted response. Digital realization follows later; analog survival must already be satisfied.

**Examples, engineering work and verification:** D-COM and P-INT compare matched/mismatched extraction; X-INV tests indistinguishable subspaces. Apparent rejection alone is not improved task performance.

