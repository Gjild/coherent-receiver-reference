Source: project/charter.md; full-source SHA256 e985bf9b74aef6aa26fc3b95403c11cae82dd083c4b8124c93def55ee7351aa6

# Founding Charter — Coherent Receiver Theory and Design

**Status:** governing project intent; technical implementation choices below are provisional until specifically accepted.

## Mission
Develop an exceptionally comprehensive, mathematically rigorous, scientifically defensible and practically applicable advanced engineering **textbook and reference** on coherent receiver theory and engineering. The audience is experienced RF engineers, including engineers with little previous specialization in coherent receivers. Codex CLI is the principal AI-assisted development environment, **not** the book's primary audience.

## Primary success criterion
After systematic end-to-end study, a qualified RF engineer should be able to approach unfamiliar coherent receiver development problems and proceed from operational need through requirements, feasibility, architecture selection, system budgets, subsystem design, synchronization, calibration, physical implementation, integration, verification and production planning, using this book as the **primary technical and methodological reference**. Component-specific information, current standards and specialized implementation details may require external sources. The book must not omit essential coherent-receiver-specific reasoning and expect the reader to reconstruct it elsewhere.

## The kind of book
- Advanced, coherent textbook **and** practical engineering design handbook.
- First principles where consequential, with derivations, assumptions, limiting cases, physical interpretation and applicability conditions.
- Integrated system reasoning: why subsystem interactions and correlations determine achievable performance.
- Learning sequence for a human engineer and practical reference navigation for future use.
- Genuine generalization to unfamiliar requirements and architectures, not memorization of worked examples.
- Contrast idealized models with nonideal hardware, calibration limitations, actual waveforms, instrument limitations and production variability.

## Required domain breadth
1. Operational needs, systems methods, specifications, feasibility and traceability.
2. Coherence definitions; complex signals, stochastic phase, correlation, spectra, estimation and synchronization.
3. Receiver architecture, frequency planning, noise, linearity, dynamic range and system error budgets.
4. RF and analog frontend, frequency conversion, synthesizers, LO/clock/reference distribution.
5. Data conversion, I/Q, digital downconversion, timing and carrier recovery, FPGA/processor consequences.
6. Multichannel coherence, amplitude/phase/delay alignment, observability, calibration and drift.
7. PCB, power, signal integrity, EMI, thermal, mechanical and environmental implementation.
8. Analytical/computational modeling, sensitivities, uncertainty, verification and measurement.
9. Manufacturing, production test, yield, reliability, configuration and lifecycle.
10. Carrier-coherent communications, arrays/DF, coherent radar/sensing and phase measurement applications.

This list describes coverage goals, **not** the final table of contents.

## Rigorous technical standards
Distinguish mathematical correctness, computational implementation correctness, physical validity, engineering adequacy and demonstrated compliance. Never claim a model is physically validated because its software tests pass. Distinguish one-/two-sided spectra, reference planes, phase accuracy/stability/repeatability, common/differential errors, deterministic/stochastic behavior, observation time, operating state and calibration dependence. Define uncertainty and identify incomplete evidence. Source citations must support the actual claims and not be fabricated.

## Scope control without dilution
- Full internal development for essential coherent-receiver reasoning.
- Selective internal development for adjacent supporting disciplines.
- Established general engineering theory and device-specific facts may be referenced externally.
- Evaluate adequacy by conceptual understanding **and** the ability to calculate, make design decisions and verify them.
- Use complete reference designs plus contrasting cases and failure analyses to check generalizability.
- Do not use page count or number of generated files as a quality metric.

## Human authority and completion
Codex may draft, research, derive, compute, check and identify issues. It cannot approve consequential engineering results on its own. Acceptance needs suitable evidence and human technical review for the declared use. Acceptance is scoped and revisable, not infallibility. Material may be released in usable intermediate editions with explicit limitations.

## Development philosophy
Use bounded technical units, minimum sufficient assurance, continuous readable outputs, consistent notation, source provenance and modest version-controlled evidence. Avoid large knowledge graphs, custom publishing engines and autonomous multi-agent infrastructure until warranted. Technical quality is uncompromising; process complexity should be proportionate.

## Immediate sequence
1. Develop the foundational reader competence and engineering capability inventory.
2. Use it with candidate reference designs to establish technical scope, dependencies and a provisional intellectual architecture.
3. Evaluate mathematical authoring/publishing tools through a genuine pilot.
4. Develop a pilot on relative phase stability in a two-channel coherent receiver from observable requirement through model, architecture choices and verification plan.
5. Revise the development system on evidence, then author progressively.

## Original intent and authority
This charter consolidates the user's clarified objective and agreed development philosophy. It does **not** claim that an inventory, chapter, design, calculation, physical model or review has been technically accepted. Requirements of the book are distinguished from provisional toolchain and repository choices in `project/decisions/`.
Source: project/technical-coverage.md; full-source SHA256 13486c7ce6600ca82a203c25386a2f7910f66216ffe6754ee7d934f997836580

Verbatim original lines 77-112:
77: ### K16 — Distributed clock and carrier-reference inference
78: 
79: **Canonical result:** offset/rate/drift and one-/two-way measurement equations with propagation/equipment delays, reference freedoms, reciprocity/asymmetry and modulo-cycle ambiguity. Distinguish RF phase, frequency, sample epoch and transport latency. **Use/assessment:** evaluate an ambiguity/asymmetry case and bounded alignment/holdover/recovery method; calculate residuals and valid outage intervals separately. **Limits:** missing geometry/delay information, delayed-feedback stability and uncertain link conditions. **Depth:** F minimum distributed inference; S representative transfer methods; E protocols/hardware. Digital resampling is a conditional realization using K19, not a prerequisite for continuous reference equations.
80: 
81: ### K17 — Sampling, timing and converter feasibility
82: 
83: **Canonical result:** bandpass/aliasing and anti-alias interfaces, aperture jitter/skew with correlations, quantization-model conditions, nonlinear/interleaving effects and conditional dither. **Use/assessment:** calculate rate, headroom, clock and driver/converter requirements for broadband, coherent low-level, blocker and recovery cases, not only a tone. **Limits:** total-waveform timing sensitivity, correlated quantization, front-end distortion, loading/common-mode/settling and typical-versus-guaranteed evidence. **Depth:** F coherent converter consequences; S converter theory; E device data/errata. K09 owns timing-disturbance construction; K14 analog interface results interact with selection.
84: 
85: ### K18 — Quadrature and conjugate-response fidelity
86: 
87: **Canonical result:** frequency/state-dependent I/Q imbalance, improper/conjugate signal models, DC offset, leakage and desired near-DC response. **Use/assessment:** estimate/apply a bounded correction and evaluate independent swept/modulated/near-DC data with level/state variation. **Limits:** suppression of a real signal, ambiguous leakage and unsupported correction envelope. **Depth:** F coherent I/Q reasoning; E device internals. Analog quadrature does not require ADC/DDC knowledge. Digital correction adds K17/K19; general calibration validity comes from K21b.
88: 
89: ### K19 — Multirate processing and finite-resource realization
90: 
91: **First treatment (a):** DDC/NCO, filtering/channelization, decimation/resampling, phase/delay, sample identity, transients and asynchronous timing estimates. **Realization (b):** numerical scaling, fixed/floating precision, overflow, coefficient error, throughput, buffering, clock-domain crossing and timestamps. **Use/assessment:** realize a bounded chain with impulse/tone/modulated and rate/reset tests; compare reference calculations and establish platform timing/resources. **Limits:** finite length, noise enhancement, startup state, lost samples and unsupported hardware claims. **Depth:** F coherent processing/resource consequences; S DSP/digital design; E HDL/core/tool details. K20 owns general correction feasibility; K23 integrates state.
92: 
93: ### K20 — Complex-response alignment and correction feasibility
94: 
95: **Canonical result:** relative amplitude/phase/delay/dispersion response and physically meaningful inverse approximation; distinguish identifiable parameters, feasible compensation and irretrievable information. Develop causality/stability/minimum-phase implications, finite latency/length, coefficient range/resolution and noise gain before choosing analog/digital realization. **Use/assessment:** calculate wideband alignment residuals and deep-attenuation/null contrasts; compare prevention, approximate correction and architecture change before irreversible combination. **Limits:** clipping/aliasing/rank loss without extra information; a notch is not automatically irrecoverable. **Depth:** F correction reasoning; S necessary systems/inverse bridge. K19 supplies digital realization only where selected; K21 owns estimation procedure and validity.
96: 
97: ### K21 — Calibration observability, procedure and maintenance
98: 
99: **First treatment (a):** measurement equations, stimulus/reference uncertainty, nuisance/reference freedoms, rank, omitted paths and desired-observable preservation. **Procedure (b):** combine metrology with observable parameters and feasible correction; acquire, estimate, apply and evaluate held-out residuals, noise gain, coefficient resources and provenance across states/band/environment. **Maintenance (c):** derive cadence, latency, downtime, drift/motion/outage policy and wanted-versus-nuisance transfer; reject invalid compensation or declare degraded operation. **Use/assessment:** demonstrate an indistinguishable calibration case, an executable bounded correction and an independent validity/retained-signal test. **Depth:** F all coherent reasoning; E instrument commands/specialist environmental inputs. A small fit residual is insufficient.
100: 
101: ### K22 — Operational metrology and uncertainty
102: 
103: **Canonical result:** instrument measurement equations including intentional method dependence, loading, fixtures, de-embedding, corrections, correlated references, floor/dynamic range, finite-record uncertainty and traceability. Reuse K07 propagation rather than create a second uncertainty theory. **Use/assessment:** execute or critically evaluate supplied measurements, calculate uncertainty and change reference/fixture topology to test sensitivity. **Limits:** apparent cancellation, instrument floors, estimator bias, insufficient degrees of freedom and nonlinear/ambiguous propagation. **Depth:** F coherent metrology; S general measurement methods; E instrument/calibration-standard particulars. K21a is conditional where calibration observability is needed; executable calibration is not prerequisite to the first measurement treatment.
104: 
105: ### K23 — State causality, integration and diagnosis
106: 
107: **First treatment (a):** initialization/reset/retune/link/reference-loss causality across applicable PLL/divider/sampler/FIFO/NCO/filter states; separate sample epoch, transport latency and RF phase. **Integration (b):** interfaces, sequencing, channel/sample identity, calibration/configuration versions, logging and valid-data gates. **Diagnosis (c):** discriminate physical hypotheses by controlled substitutions and interventions, preserving raw data and state. **Use/assessment:** implement/exercise bounded transitions and fault cases and interpret exposure/confidence through K25; evaluate a discriminating diagnostic experiment. **Depth:** F coherent state/diagnosis; S software/configuration practice; E device-specific state guarantees. No universal digital chain is assumed.
108: 
109: ### K24 — Physical and environmental realization
110: 
111: **First treatment (a):** translate sensitivity allocations into routing, return-current, power/filter, shielding, coupling/isolation and test-access constraints; calculate representative aggressor/supply-to-phase paths. **Environmental refinement (b):** thermal coefficients/gradients/time constants, strain, vibration, connectors, warmup and mitigation residuals. **Use/assessment:** evaluate concrete implementation constraints and controlled aggressor/gradient/handling evidence. **Limits:** equal physical lengths, uniform chamber results and generic layout rules do not establish electrical matching or field validity. **Depth:** F coherent consequences; S SI/PI/EMI/thermal/mechanical bridges; E materials/fabrication/qualification facts. Correction interface may be supplied before maintenance policy is developed.
112: 
Verbatim original lines 153-166:
153: | K11 first framing | Reader operational/RF baseline; K01 for quantitative observable definitions | Application need supplied; no budget result assumed |
154: | K11 quantitative | K05 information/ambiguity; K07 bounded calculation; K01 requirement conditions | Add K08/K04 spatial constraints, K10 detection, K09 disturbance constraints; technology/interface envelopes may be supplied |
155: | K12 | K01 signal/reference signs; K03 phase/transfer/observation reasoning | Ideal sampling interface first; K17/K19 refine implementation |
156: | K13 | K11 quantitative feasibility/architecture; K12 transfer; K09 physical sources; K04/K07 propagation/uncertainty | Add K08 geometry and K16 distributed terms; declared application/subsystem specifications first |
157: | K14 | K12 transfer, K13 allocations, K07 adequacy and K09 disturbance construction | Add K17 for an actual converter interface; operating/technology envelopes supplied |
158: | K15a; K15b | K15a: K06 loop behavior, K12 transfer, K13 allocations. K15b: K15a plus K03 common/differential transfer | Add K16 remote inference; branch/interface/environment parameters supplied |
159: | K16 | K01 clock/reference definitions; K03 stability; K05 identifiability; K06 loop/holdover | Add K04/K08 joint geometry; K17/K19 only for sampled-stream realization |
160: | K17 | K12 sampling/frequency representation; K13 allocations; K09 timing/noise; K07 approximation | Analog drive supplied initially, reconciled with K14; actual state guarantees external |
161: | K18 | K01 complex signals; K02 improper/noise models; K05 estimation; K12/K14 path behavior | Add K17/K19 for digital correction; K21b for full procedural validity |
162: | K19a; K19b | K19a: K17 sample identity, K12 transfer, K03 filtering, K07 error. K19b: K19a plus internal digital-resource bridge | Add K04/K20 for matrix equalization; K16 supplies remote-clock estimates; platform constraints external |
163: | K20 | K12 complex transfer; K13 allocations; K04/K07 conditioning/error; internal causal/stable inverse bridge | Add K08 antenna response, K15 distribution, K19 digital realization; no calibration procedure needed to analyze correction feasibility |
164: | K21a | K01 observables, K05 identifiability, K04 rank and K07 sensitivity | Add K08 external paths, K20 multichannel alignment, K09 physical noise |
165: | K22 | K01 measurand, K03 finite observation, K05 estimator behavior, K07 uncertainty | Add K21a calibration references; K04/K09 coupled noise; K17/K19 sampled measurement |
166: | K21b | K21a identified freedoms; K22 metrology; K05/K07 inference/uncertainty | Add K18/K19/K20 selected correction, K23a state validity, K08 field/sensor calibration |
Verbatim original lines 203-206:
203: | CAP-018 | C/M/A/D/I/V | K17; K09 complete-waveform timing | Evaluated converter/driver/clock/range selection for broadband, blocker, low-level coherent and recovery cases; separate data arrival from sample timing | X-BLK, X-STATE; U-07 |
204: | CAP-019 | C/M/A/D/I/V | K18; add K17/K19 digital, K21b procedure | Estimated/applied I/Q correction; independent desired/conjugate response versus frequency, level and state, including true near-DC signal | P-COM, P-MET; U-10 |
205: | CAP-020 | C/M/A/D/I/V | K19a; add K20 correction, K16 clock estimates | Executed rate/filter/NCO/resampling chain; quantified phase/delay, alias rejection, noise gain, finite-length residual and reset/sample faults | X-STATE, X-INV; U-07/U-08 |
206: | CAP-021 | C/A/D/I/V | K19b | Executed precision/load case with overflow/truncation/sample-loss analysis and platform resource/timing evidence | X-STATE; U-07 |
Source: project/annotated-toc.md; full-source SHA256 9441c0715abdab2c7da078ee8729dc18c6501bf6b6916356d69fbd4952d5cdcb

Verbatim original lines 434-510:
434: ### Chapter 17 — Sampling and converter feasibility
435: 
436: **Objective:** Select rate, range, driver and clock using broadband and nonideal cases.
437: 
438: **Entry:** Chapters 6, 9, 11–12; reconcile analog drive with 14.
439: 
440: **Canonical ownership:** K17. Shared results used here retain their original homes.
441: 
442: #### 17.1 Sampling and anti-alias interfaces
443: 
444: Develop bandpass/alias placement, filtering and sample identity; distinguish arrival time from analog sampling epoch.
445: 
446: #### 17.2 Timing and correlation
447: 
448: Apply Chapter 9 complete-waveform sensitivity to aperture jitter/skew and clock/channel correlations, with conditional approximations.
449: 
450: #### 17.3 Quantization and distortion
451: 
452: Develop quantization-model conditions, coherent low-level exceptions, nonlinear/interleaving artifacts and conditional dither costs.
453: 
454: #### 17.4 Compatible selection
455: 
456: Calculate clock/range/driver/loading/common-mode/settling and recovery requirements. Compare technologies with guarantees, typical data and characterization needs separated.
457: 
458: **Examples, engineering work and verification:** X-BLK/X-STATE require broadband, blocker, low-level and recovery assessments beyond a sine test. Include power/reference isolation and valid-state consequences.
459: 
460: ### Chapter 18 — Quadrature and conjugate-response fidelity
461: 
462: **Objective:** Estimate and correct I/Q errors while preserving real desired information.
463: 
464: **Entry:** Chapters 1–2, 5, 11 and 14; digital correction adds 17/19.
465: 
466: **Canonical ownership:** K18. Shared results used here retain their original homes.
467: 
468: #### 18.1 Quadrature models
469: 
470: Develop frequency/state-dependent desired and conjugate response, improper signals, imbalance, DC offset and leakage.
471: 
472: #### 18.2 Stimulus and estimation
473: 
474: Choose observations that distinguish leakage, response error and genuine near-DC signal; expose ambiguous cases.
475: 
476: #### 18.3 Bounded compensation
477: 
478: Develop analog/digital options and residual/noise/resource consequences. Reuse Chapter 20 general feasibility for advanced correction.
479: 
480: #### 18.4 Independent fidelity checks
481: 
482: Plan swept/modulated/near-DC level/state checks independent of fitting, then integrate procedural validity through Chapter 23.
483: 
484: **Examples, engineering work and verification:** D-COM/D-MET need estimated/applied correction and retained desired response. Suppressing a real signal does not count as successful offset removal.
485: 
486: ### Chapter 19 — Multirate processing and finite resources
487: 
488: **Objective:** Realize a bounded sample-preserving chain within numerical and platform limits.
489: 
490: **Entry:** Chapters 3, 6, 11 and 17; correction adds 20, remote estimates 16.
491: 
492: **Canonical ownership:** K19a/b. Shared results used here retain their original homes.
493: 
494: #### 19.1 DDC, NCO and channelization
495: 
496: Develop translation/filter/decimation response, phase, group delay and sample identity through tuning and reset.
497: 
498: #### 19.2 Resampling and transients
499: 
500: Develop fractional delay/asynchronous estimates, finite filters and startup effects. General inverse feasibility follows in Chapter 20; do not teach equalization as unconstrained inversion here.
501: 
502: #### 19.3 Numerical realization
503: 
504: Calculate scaling, precision, coefficient error, truncation bias, overflow and reference-comparison residuals.
505: 
506: #### 19.4 Real-time interfaces
507: 
508: Calculate throughput, buffering, latency, clock-domain crossing, timestamps and loss detection. Establish platform resource/timing evidence rather than infer it from floating-point agreement.
509: 
510: **Examples, engineering work and verification:** D-COM and X-STATE exercise impulse/tone/modulated inputs, rate/reset changes, one-sample and NCO faults. A finite-length correction revisit after 20 quantifies noise gain and residual.
