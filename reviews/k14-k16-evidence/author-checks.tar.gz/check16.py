from pathlib import Path
import sys,math,json,re,xml.etree.ElementTree as E
sys.path.insert(0,'engineering/examples');import subsystem_models as m,visual_foundations as v
v.OUT=Path('/tmp/k1416/svg16');v.OUT.mkdir(exist_ok=True);m.unit16()
assert all(f.read_bytes()==(Path('book/figures')/f.name).read_bytes() for f in v.OUT.glob('*.svg'))
lin=lambda a,b:[a+(b-a)*i/240 for i in range(241)]
logs=lambda a,b:[10**x for x in lin(math.log10(a),math.log10(b))]
checks=[]
def check(name,y,xlim,ylim,curves,lx=False,ly=False):
 top=y+92;fx=math.log10 if lx else lambda x:x;fy=math.log10 if ly else lambda x:x
 paths=[]
 for p in E.parse('book/figures/'+name+'.svg').getroot():
  pts=[tuple(map(float,q)) for q in re.findall(r'[ML]([\d.-]+),([\d.-]+)',p.attrib.get('d',''))]
  if p.attrib.get('stroke-width')=='2.8' and len(pts)>2 and top-.001<=pts[0][1]<=top+195.001:paths.append(pts)
 expected=[]
 for xs,ys in curves:
  chunk=[]
  for x,z in zip(xs,ys):
   if xlim[0]<=x<=xlim[1] and ylim[0]<=z<=ylim[1]:chunk.append((100+780*(fx(x)-fx(xlim[0]))/(fx(xlim[1])-fx(xlim[0])),top+195-195*(fy(z)-fy(ylim[0]))/(fy(ylim[1])-fy(ylim[0]))))
   else:
    if len(chunk)>1:expected.append(chunk)
    chunk=[]
  if len(chunk)>1:expected.append(chunk)
 assert len(paths)==len(expected),(name,y,len(paths),len(expected))
 for got,w in zip(paths,expected):
  assert len(got)==len(w)
  error=max(max(abs(a-c),abs(b-d)) for (a,b),(c,d) in zip(got,w));assert error<.000501,(name,error)
  checks.append({'figure':name,'vertices':len(got),'error_px':error})

aa=lin(-40,40)
check('remote-asymmetry-rate',70,(-40,40),(-20,20),[(aa,[a/2 for a in aa])])
b=lin(1,24)
check('remote-asymmetry-rate',510,(1,24),(0,.045),[(b,[1.02e9*40e-12/a+.001*a/2 for a in b]),(b,[.01]*241),(b,[1.02e9*40e-12/a for a in b]),(b,[.001*a/2 for a in b])])
t=logs(.0001,100)
check('remote-holdover-bounds',70,(.0001,100),(.005,10000),[(t,[.01+360*.01*a+180*.001*a*a for a in t]),(t,[.05]*241)],True,True)
check('remote-holdover-bounds',520,(.0001,100),(.1,10),[(t,[(200e-12+(.01*a+.0005*a*a)/1.02e9)*1e9 for a in t]),(t,[1]*241)],True,True)
x=[0,11.104945,11.104945,24,24,27,27,40]
check('remote-recovery-control',70,(0,40),(-.1,1.3),[(x,[1]*8),(x,[1,1,0,0,1,1,0,0])])
f=lin(0,60)
check('remote-recovery-control',510,(0,60),(-130,90),[(f,[90-math.degrees(2*math.pi*v*.01) for v in f]),(f,[45]*241),(f,[0]*241)])
r={'reproduced':4,'checks':checks,'vertices':sum(x['vertices'] for x in checks)}
Path('/tmp/k1416/k16-graphical.json').write_text(json.dumps(r,indent=2)+'\n');print('vertices',r['vertices'])
