from pathlib import Path
import sys,math,json,re,xml.etree.ElementTree as E
sys.path.insert(0,'engineering/examples');import subsystem_models as m,visual_foundations as v
v.OUT=Path('/tmp/k1416/svg15');v.OUT.mkdir(exist_ok=True);m.unit15()
assert all(f.read_bytes()==(Path('book/figures')/f.name).read_bytes() for f in v.OUT.glob('*.svg'))
lin=lambda a,b:[a+(b-a)*i/240 for i in range(241)]
logs=lambda a,b:[10**x for x in lin(math.log10(a),math.log10(b))]
checks=[]
def check(name,y,xlim,ylim,curves,lx=False,ly=False):
 top=y+92;fx=math.log10 if lx else lambda x:x;fy=math.log10 if ly else lambda x:x
 paths=[]
 for p in E.parse('book/figures/'+name+'.svg').getroot():
  pts=[tuple(map(float,q)) for q in re.findall(r'[ML]([\d.-]+),([\d.-]+)',p.attrib.get('d',''))]
  if p.attrib.get('stroke-width')=='2.8' and len(pts)>2 and top-.001<=pts[0][1]<=top+195.001:paths.append(pts)
 expected=[]
 for xs,ys in curves:
  chunk=[]
  for x,z in zip(xs,ys):
   if xlim[0]<=x<=xlim[1] and ylim[0]<=z<=ylim[1]:chunk.append((100+780*(fx(x)-fx(xlim[0]))/(fx(xlim[1])-fx(xlim[0])),top+195-195*(fy(z)-fy(ylim[0]))/(fy(ylim[1])-fy(ylim[0]))))
   else:
    if len(chunk)>1:expected.append(chunk)
    chunk=[]
  if len(chunk)>1:expected.append(chunk)
 assert len(paths)==len(expected),(name,y,len(paths),len(expected))
 for got,w in zip(paths,expected):
  assert len(got)==len(w)
  error=max(max(abs(a-c),abs(b-d)) for (a,b),(c,d) in zip(got,w));assert error<.000501,(name,error)
  checks.append({'figure':name,'vertices':len(got),'error_px':error})
def ps(f,n):
 d=n**4+f**4
 return 102**2*1e-16*(n**4+2*n*n*f*f)/d+1e-3*f**4/((f*f+1)*d)
def rms(n):
 from visual_foundations import quad
 edges=[10,100,1000,10000,100000,1e6]
 return math.degrees(math.sqrt(2*sum(quad(lambda f:ps(f,n),a,b,2048) for a,b in zip(edges,edges[1:]))))
f=logs(10,1e6)
check('pll-loop-tradeoff',70,(10,1e6),(1e-16,1e-9),[(f,[ps(x,n) for x in f]) for n in [2000,10000,20000,40000]],True,True)
n=lin(1000,50000);x=[v/1000 for v in n]
check('pll-loop-tradeoff',525,(1,50),(0,.09),[(x,[rms(v) for v in n]),(x,[.03]*241)])
wait=lambda n:1e6*math.log(math.sqrt(2)/.01)/((1/math.sqrt(2))*2*math.pi*n)
check('pll-loop-tradeoff',980,(1,50),(0,1200),[(x,[wait(v) for v in n]),(x,[100]*241)])
s=logs(1e-12,2e-10)
check('lo-blocker-contract',70,(1e-12,2e-10),(-176,-156),[(s,[10*math.log10(1e-9*(ps(1e7,20000)+2e-12+v)/.001) for v in s]),(s,[-162]*241)],True)
b=logs(1e-7,1e-3);ratio=math.sqrt(10**(42/10))
check('lo-blocker-contract',520,(1e-7,1e-3),(.0001,10),[(b,[math.degrees(math.asin(ratio*v/2)) for v in b]),(b,[.02]*241)],True,True)
r={'reproduced':4,'checks':checks,'vertices':sum(x['vertices'] for x in checks)}
Path('/tmp/k1416/k15-graphical.json').write_text(json.dumps(r,indent=2)+'\n');print('vertices',r['vertices'])
